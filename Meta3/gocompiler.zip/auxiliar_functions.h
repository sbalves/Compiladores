 #include "structures.h"

bool is_statement_token(char * id);
bool is_unary_operator(char * id);
bool is_realtional_operator(char * id);
bool is_arithmetic_operator(char * id);
bool is_logical_operator(char * id);